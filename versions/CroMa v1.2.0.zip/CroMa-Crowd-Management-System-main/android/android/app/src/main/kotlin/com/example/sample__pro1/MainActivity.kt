package com.example.sample__pro1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
