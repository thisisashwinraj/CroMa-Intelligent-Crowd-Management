magic module
============

.. automodule:: magic
   :members:
   :undoc-members:
   :show-inheritance:
