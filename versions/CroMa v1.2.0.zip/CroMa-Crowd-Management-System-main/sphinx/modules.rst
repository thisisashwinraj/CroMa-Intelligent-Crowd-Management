Desktop
=======

.. toctree::
   :maxdepth: 4

   magic
   test1
