---
name: Documentation improvement
about: Create a report to help us improve the documentation. Alternatively you can just open a pull request with the suggested change.
title: ''
labels: Documentation
assignees: ''

---

**Describe the issue:**
A clear and concise description of the confusion introduced in the documentation.

**Suggest an alternative/fix:**
Tell us how we could improve the documentation in regard of the linked issue
